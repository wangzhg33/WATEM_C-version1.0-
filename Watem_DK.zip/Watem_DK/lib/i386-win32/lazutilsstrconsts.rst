
# hash value = 182357808
lazutilsstrconsts.lrsmodified='  modified '


# hash value = 91975905
lazutilsstrconsts.lrsinvalidcharset='The char set in mask "%s" is not val'+
'id!'


# hash value = 41554000
lazutilsstrconsts.lrssize='  size '


# hash value = 29165140
lazutilsstrconsts.lrsfiledoesnotexist='file "%s" does not exist'


# hash value = 86867205
lazutilsstrconsts.lrsfileisadirectoryandnotanexecutable='file "%s" is a d'+
'irectory and not an executable'


# hash value = 226065091
lazutilsstrconsts.lrsreadaccessdeniedfor='read access denied for %s'


# hash value = 70358923
lazutilsstrconsts.lrsadirectorycomponentindoesnotexistorisadanglingsyml2='a'+
' directory component in %s does not exist or is a dangling symlink'


# hash value = 256042601
lazutilsstrconsts.lrsadirectorycomponentinisnotadirectory2='a directory c'+
'omponent in %s is not a directory'


# hash value = 70358923
lazutilsstrconsts.lrsadirectorycomponentindoesnotexistorisadanglingsyml='a'+
' directory component in %s does not exist or is a dangling symlink'


# hash value = 256042601
lazutilsstrconsts.lrsadirectorycomponentinisnotadirectory='a directory co'+
'mponent in %s is not a directory'


# hash value = 184500041
lazutilsstrconsts.lrsinsufficientmemory='insufficient memory'


# hash value = 91797227
lazutilsstrconsts.lrshasacircularsymboliclink='%s has a circular symbolic'+
' link'


# hash value = 210099275
lazutilsstrconsts.lrsisnotasymboliclink='%s is not a symbolic link'


# hash value = 165471237
lazutilsstrconsts.lrsisnotexecutable='%s is not executable'


# hash value = 171873762
lazutilsstrconsts.lrsunabletocreateconfigdirectorys='Unable to create con'+
'fig directory "%s"'


# hash value = 160116227
lazutilsstrconsts.lrsprogramfilenotfound='program file not found %s'


# hash value = 171227939
lazutilsstrconsts.lrscannotexecute='can not execute %s'


# hash value = 94862996
lazutilsstrconsts.lrsnodeset='node set'


# hash value = 157690654
lazutilsstrconsts.lrsboolean='boolean'


# hash value = 123484354
lazutilsstrconsts.lrsnumber='number'


# hash value = 128684103
lazutilsstrconsts.lrsstring='string'


# hash value = 143677013
lazutilsstrconsts.lrsvarnoconversion='Conversion from %s to %s not possib'+
'le'


# hash value = 111178148
lazutilsstrconsts.lrsscannerunclosedstring='String literal was not closed'+


# hash value = 169975714
lazutilsstrconsts.lrsscannerinvalidchar='Invalid character'


# hash value = 182767806
lazutilsstrconsts.lrsscannermalformedqname='Expected "*" or local part af'+
'ter colon'


# hash value = 5640818
lazutilsstrconsts.lrsscannerexpectedvarname='Expected variable name after'+
' "$"'


# hash value = 242831106
lazutilsstrconsts.lrsparserexpectedleftbracket='Expected "("'


# hash value = 242831122
lazutilsstrconsts.lrsparserexpectedrightbracket='Expected ")"'


# hash value = 49378373
lazutilsstrconsts.lrsparserbadaxisname='Invalid axis name'


# hash value = 147982773
lazutilsstrconsts.lrsparserbadnodetype='Invalid node type'


# hash value = 221376949
lazutilsstrconsts.lrsparserexpectedrightsquarebracket='Expected "]" after'+
' predicate'


# hash value = 63748814
lazutilsstrconsts.lrsparserinvalidprimexpr='Invalid primary expression'


# hash value = 160350798
lazutilsstrconsts.lrsparsergarbageafterexpression='Unrecognized input aft'+
'er expression'


# hash value = 41668873
lazutilsstrconsts.lrsparserinvalidnodetest='Invalid node test (syntax err'+
'or)'


# hash value = 249635298
lazutilsstrconsts.lrsevalunknownfunction='Unknown function: "%s"'


# hash value = 86308754
lazutilsstrconsts.lrsevalunknownvariable='Unknown variable: "%s"'


# hash value = 43558403
lazutilsstrconsts.lrsevalinvalidargcount='Invalid number of function argu'+
'ments'

