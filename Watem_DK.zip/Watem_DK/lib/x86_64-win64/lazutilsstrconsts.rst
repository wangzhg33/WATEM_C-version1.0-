
# hash value = 182357808
lazutilsstrconsts.rsmodified='  modified '


# hash value = 91975905
lazutilsstrconsts.sinvalidcharset='The char set in mask "%s" is not valid'+
'!'


# hash value = 41554000
lazutilsstrconsts.rssize='  size '

